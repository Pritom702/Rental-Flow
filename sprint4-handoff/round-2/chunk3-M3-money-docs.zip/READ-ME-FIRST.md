# Sprint 4 (round 2) — your chunk (M3 · Promit)

Bangladeshi Taka in the PDF exports, document totals and seed prices. PDFs print \"BDT\" rather than the taka sign because jsPDF's built-in Helvetica has no glyph for it and would render an empty box.

## How to use this (VS Code)

1. Make sure your repo is **clean and up to date** first:
   ```
   git checkout main
   git pull
   git status          # must say "nothing to commit"
   ```
2. Create your branch:
   ```
   git checkout -b s4-m3-money-docs
   ```
3. **Extract this zip over the repository root**, keeping the folder structure.
   The paths inside (`client/src/...`, `server/src/...`) line up with the repo,
   so the files land in the right places and replace the old versions.
4. In VS Code, open the Source Control panel and check the changed files look
   right, then commit and push:
   ```
   git add -A
   git commit -m "feat(F15): Taka amounts in PDFs, statements and seed data"
   git push -u origin s4-m3-money-docs
   ```
5. Open a Pull Request into `main` on GitHub.

## Two important warnings

**These are complete files, not patches — they overwrite.** If you have your own
uncommitted edits to any of the files listed below, they will be lost. Commit or
stash your work before extracting.

**Merge order matters this round.** @pritom702's branch `s4-m2-platform`
(PR #3) must be merged into `main` **before** yours, because it adds
`client/src/money.js` and `server/src/app.js`, which these files import.
If you merge first, the build will fail.

## Commit as yourself

Use your own GitHub account and its email, so the contribution history is
genuinely per-person — this is a course rule (see `SPRINT_PLAN.md`).

## Files in this chunk

```
client/src/pages/Documents.jsx
client/src/pdf.js
server/src/documentUtils.js
server/src/documentUtils.test.js
server/src/seed.js
```

## Before you push

```
cd server && npm test      # 48 tests must pass
cd ../client && npm run build
```
