# Sprint 5 — your chunk (M4 · Radowan)

The rebuilt design system and app shell, plus three new features: F21 one-time NID verification for damage control, F22 user profiles with permanent payment methods, and F23 the renter identity check shown before approving a booking.

## How to use this (VS Code)

1. Make sure your repo is **clean and up to date** first:
   ```
   git checkout main
   git pull
   git status          # must say "nothing to commit"
   ```
2. Create your branch:
   ```
   git checkout -b s5-m4-design-profile
   ```
3. **Extract this zip over the repository root**, keeping the folder structure.
   The paths inside (`client/src/...`, `server/src/...`) line up with the repo,
   so the files land in the right places and replace the old versions.
4. In VS Code, open the Source Control panel and check the changed files look
   right, then commit and push:
   ```
   git add -A
   git commit -m "feat(F21,F22,F23): NID verification, user profiles and renter identity check"
   git push -u origin s5-m4-design-profile
   ```
5. Open a Pull Request into `main` on GitHub.

## Two important warnings

**These are complete files, not patches — they overwrite.** If you have your own
uncommitted edits to any of the files listed below, they will be lost. Commit or
stash your work before extracting.

**Merge order matters this sprint.** @pritom702's branch `s5-m2-platform`
(PR #3) must be merged into `main` **before** yours, because it adds
`client/src/money.js` and `server/src/app.js`, which these files import.
If you merge first, the build will fail.

## Commit as yourself

Use your own GitHub account and its email, so the contribution history is
genuinely per-person — this is a course rule (see `SPRINT_PLAN.md`).

## Files in this chunk

```
client/src/App.jsx
client/src/components/NidForm.jsx
client/src/components/PaymentMethods.jsx
client/src/components/RenterModal.jsx
client/src/icons.jsx
client/src/pages/Dashboard.jsx
client/src/pages/Landing.jsx
client/src/pages/Maintenance.jsx
client/src/pages/Profile.jsx
client/src/styles.css
server/src/profileUtils.js
server/src/profileUtils.test.js
server/src/routes/profile.js
server/src/schema_profile.sql
server/src/seedProfile.js
server/src/uploads/demo-nid-back.svg
server/src/uploads/demo-nid-front.svg
```

## Before you push

```
cd server && npm test      # 48 tests must pass
cd ../client && npm run build
```
